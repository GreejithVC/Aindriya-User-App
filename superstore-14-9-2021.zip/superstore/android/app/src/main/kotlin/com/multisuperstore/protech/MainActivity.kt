package userapp.albuysmart.com

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
